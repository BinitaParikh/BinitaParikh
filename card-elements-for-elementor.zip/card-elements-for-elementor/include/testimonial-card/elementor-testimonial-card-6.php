<div class="container">
    <div class="testimonial6">
        <div class="pic">
            <img src="<?php echo $settings['profile_image']['url']; ?>">
            </div>
            <p class="description"><?php echo $settings['testimonial_description']; ?></p>
            <h3 class="name"><?php echo $settings['name'];?></h3>
            <span class="post"><?php echo $settings['position']; ?></span>
    </div>
</div>